#ifndef CLIENT_H_
#define CLIENT_H_

void clientMain(int port);

#endif
